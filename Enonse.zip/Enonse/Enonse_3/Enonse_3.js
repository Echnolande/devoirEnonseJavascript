console.info('Bonjour');
console.error('A');