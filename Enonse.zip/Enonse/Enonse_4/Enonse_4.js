const non = "Echnolande JACQUES";
let laj = 23;
document.write("Non mw se "+non+", mw gen "+laj+" lane");