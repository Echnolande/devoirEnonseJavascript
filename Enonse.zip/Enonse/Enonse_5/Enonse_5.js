let nonb1 = prompt("Rantre yon nonb");
let nonb2 = prompt("Rantre yon lot nonb");

let reziltaAdisyon = nonb1 + nonb2;
let reziltaSoustrakdisyon = nonb1 - nonb2;
let reziltaMiltiplikasyon = nonb1 * nonb2;
let reziltaDivizyon = nonb1 / nonb2;

document.write("Adisyon:------------------>"+reziltaAdisyon);
document.write("Divizyon:---------------------->"+reziltaDivizyon);
document.write("Soustraksyon:-------------------------->"+reziltaSoustrakdisyon);
document.write("Miltiplikasyon:------------------------------>"+reziltaMiltiplikasyon);